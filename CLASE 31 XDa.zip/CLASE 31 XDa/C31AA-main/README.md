# InvasiónPirataEtapa-2.5
crear múltiples balas de cañón.
